#! /bin/bash
echo "Triggering Credential Gathering Protection SILENT"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890ps_s.txt
