#! /bin/bash
echo "Triggering Container escape Protection (LINUX) BLOCK"

touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890container_escaping_protection.txt
