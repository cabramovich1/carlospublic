#! /bin/bash
echo "Triggering Cryptominers Protection SILENT" 
touch  ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890crypto_s.txt
