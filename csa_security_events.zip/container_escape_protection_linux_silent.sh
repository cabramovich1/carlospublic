#! /bin/bash
echo "Triggering Container escape Protection (LINUX) SILENT"

touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890container_escaping_protection_s.txt
