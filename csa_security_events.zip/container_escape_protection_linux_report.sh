#! /bin/bash
echo "Triggering Container escape Protection (LINUX) REPORT"

touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890container_escaping_protection_r.txt
