#! /bin/bash
echo "Triggering Anti Webshell Protection REPORT"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890wd.txt
