#! /bin/bash
echo "Triggering Cryptominers Protection REPORT" 
touch  ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890crypto_r.txt
