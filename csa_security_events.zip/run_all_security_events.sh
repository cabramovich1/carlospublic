#! /bin/bash

./anti_webshell_block.sh
./anti_webshell_report.sh
./anti_webshell_silent.sh
./container_escape_protection_linux_block.sh
./container_escape_protection_linux_report.sh
./container_escape_protection_linux_silent.sh
./credential_gathering_protection_block.sh
./credential_gathering_protection_report.sh
./credential_gathering_protection_silent.sh
./cryptominers_protection_block.sh
./cryptominers_protection_report.sh
./cryptominers_protection_silent.sh
./finalcial_malware_threat_block.sh
./finalcial_malware_threat_report.sh
./finalcial_malware_threat_silent.sh
./gbtp_linux_block.sh
./gbtp_linux_silent.sh

