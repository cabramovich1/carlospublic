#! /bin/bash
echo "Triggering Credential Gathering Protection REPORT"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890ps_r.txt
