#! /bin/bash
echo "Triggering Anti Webshell Protection BLOCK"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890wd.txt
