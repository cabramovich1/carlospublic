#!/bin/bash
echo "Triggering Global Behavioral Threat Protection Rules Block"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890.txt
