#! /bin/bash
echo "Triggering Credential Gathering Protection BLOCK"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890ps.txt
