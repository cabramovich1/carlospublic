#! /bin/bash
echo "Triggering Anti Webshell Protection SILENT"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890wd.txt
