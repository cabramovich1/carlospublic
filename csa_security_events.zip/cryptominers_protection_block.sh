#! /bin/bash
echo "Triggering Cryptominers Protection BLOCK" 
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890crypto.txt
