#!/bin/bash
echo "Triggering Global Behavioral Threat Protection Rules SILENT"
touch ptkutkyuqwertyuiopasdfghjklzxcvbnm1234567890s.txt
