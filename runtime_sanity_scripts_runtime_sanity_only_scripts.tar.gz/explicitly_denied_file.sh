#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Explicitly denied file paths\n….Triggering....\n"

echo test > /tools/denied/test.txt

echo -e "\nEvent information:\nCategory:Filesystem / Explicitly Denied File\nATT%CK technique:NO TECHNIQUE\nMessage:/usr/bin/bash changed explicitly monitored file /tools/denied/test.txt"
