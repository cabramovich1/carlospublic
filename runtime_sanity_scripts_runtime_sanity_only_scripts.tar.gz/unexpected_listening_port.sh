#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:NO TOGGLE,All other network activity\nNote:Processes started from modified binaries MUST BE DISABLE\n....Triggering....\n"

port=$[ $RANDOM % 10008 + 10005 ]
echo $port
nc -k -l -p 10008 &
sleep 20
pkill -9 nc

echo -e "\nEvent information:\nCategory:Network / Unexpected Listening Port\nATT%CK technique:NO TECHNIQUE\nMessage:Container process /usr/bin/nc.openbsd is listening on unexpected port 10008"
