#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:NO TOGGLE,All other network activity\nNote:Networking activity from modified binaries MUST BE DISABLE\n....Triggering....\n"

curl 8.8.4.4:9453 &

echo -e "\nEvent information:\nCategory:Network / Unexpected Outbound Port\nATT%CK technique:Exfiltration, Command And Control/ General\nMessage:Outbound connection by /usr/bin/curl to an unexpected port: 9453 IP: 8.8.4.4"
