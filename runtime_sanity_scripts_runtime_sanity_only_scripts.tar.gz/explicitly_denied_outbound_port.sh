#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Denied explicitly outbound  ports field\n\n….Triggering....\n"

curl 8.8.4.4:2223 &

echo -e "\nEvent information:\nCategory:Network / Explicitly Denied Outbound Port \nATT%CK technique:NO TECHNIQUE\nMessage:Outbound connection by /usr/bin/curl to port 2223 (IP: 8.8.4.4) is explicitly denied by a runtime rule"


