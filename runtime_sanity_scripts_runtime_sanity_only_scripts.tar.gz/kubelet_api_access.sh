#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nNote:Currently in order for the incident to appear, 'Networking activity from modified binaries' toggle DISABLE Networking tab of relevant runtime rule should be off\nEffect:is taken from Networking tab of container runtime rule\n\n....Triggering....\n"

curl http://169.254.169.254:10250 &

echo -e "\nEvent information:\nCategory:Kuberenetes | Kubelet API Access \nATT%CK technique:Access the Kubelet Main API\nMessage:Container queried kubelet API at 169.254.169.254:10250"
