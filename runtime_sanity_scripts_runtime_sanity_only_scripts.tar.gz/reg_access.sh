#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Denied file paths fields\n\n...Triggering....\n"

echo koko > /tools/kok.txt

echo -e "\nEvent information:\nCategory:Filesystem / Reg File Access\nATT%CK technique:NO TECHNIQUE\nMessage:/usr/bin/bash wrote a suspicious file to /tools/kok.txt
