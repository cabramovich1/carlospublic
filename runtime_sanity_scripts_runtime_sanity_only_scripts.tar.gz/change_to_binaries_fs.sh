#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Changes to binaries\nNote:On your container runtime rule, switch off 'Processes started from modified binaries' toggle on Processes tab and 'Detection of encrypted/packed binaries' toggle on Filesystem tab\n….Triggering....\n"

gcc -static -o test test.c

echo -e "\nEvent information:\nCategory:Filesystem / Exec File Access\nATT%CK technique:Compile After Delivery\nMessage:/usr/bin/x86_64-linux-gnu-ld.bfd changed the binary /tools/test. MD5: 2e37b643b4fc5d85ae19596169b3bf6a"
