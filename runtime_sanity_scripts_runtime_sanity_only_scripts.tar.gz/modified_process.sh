#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nTOGGLE:Processes started from modified binaries\n\n....Triggering....\n"

cp /usr/bin/curl curl-carlos && ./curl-carlos --help

echo -e "\nEvent information:\nCategory:Processes / Modified Process \nATT%CK technique:Foreign Binary Execution\nMessage:A modified executable /tools/curl-carlos was launched. Full command: ./curl-carlos --help"
