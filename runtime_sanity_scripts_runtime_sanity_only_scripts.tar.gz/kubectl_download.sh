#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nNote:Currently in order for the incident to appear, 'Networking activity from modified binaries' toggle DISABLE Networking tab of relevant runtime rule should be off\nEffect:is taken from Filesystem  tab of container runtime rule\nNote: Prevent effect is not supported for this event\n\n....Triggering....\n"

curl -L "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl" -o /tools/packaged/kubectl & 

echo -e "\nEvent information:\nCategory:Kuberenetes | Kubectl Downloaded\nATT%CK technique:Ingress Tool Transfer, Software Deployment Tools\nMessage:/usr/bin/curl downloaded kubectl to container (/tools/packaged/kubectl). MD5: fe8ca6f9ef6dec468dbfd0a6e1c9d63c"
