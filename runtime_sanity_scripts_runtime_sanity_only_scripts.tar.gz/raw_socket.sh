#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Raw Sockets\nNote:Port Scanning MUST BE DISABLE\n...Triggering....\n"

nmap -p 80,8080,8081,8082,8083,8084,2375,10250,6443,9998 8.8.8.8

echo -e "\nEvent1 information:\nCategory:Network / Suspicious Network Activity \nATT%CK technique:Man-in-the-Middle\nMessage:Process /usr/bin/nmap performed suspicious raw network activity, this might indicate an ARP spoofing attempt”

echo -e "\nEvent2 information:\nCategory:Network / Suspicious Network Activity \nATT%CK technique:Network Service Scanning\nMessage:Process /usr/bin/nmap performed suspicious raw network activity, this might indicate a port scanning attempt”
