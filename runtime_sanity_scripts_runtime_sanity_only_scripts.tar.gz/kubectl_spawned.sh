#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nNote:Effect is taken from Processes tab of container runtime rule\n\n....Triggering....\n"

/tools/kubectl --help

echo -e "\nEvent information:\nCategory:Kuberenetes | Kubectl Spawned\nATT%CK technique:Access the Kubernetes API Server, Software Deployment Tools\nMessage:kubectl launched inside the container. Full command: /tools/kubectl --help"
