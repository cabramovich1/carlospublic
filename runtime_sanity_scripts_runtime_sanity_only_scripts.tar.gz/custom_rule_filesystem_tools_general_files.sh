#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:RUNTIME CUSTOM RULE WILL HAVE PRIORITY OVER RUNTIME CONTAINER POLICY\n\n….Triggering....\n"

echo custom-rule-fs  >> general-files/custom-rule-fs.txt

echo -e '\nEvent information:\nCategory:Filesystem / Custom Rule\nATT%CK technique:NO TECHNIQUE\nMessage:mailto: carlos@mail.com; auth: [*****] DD (name: "bash", parent: "bash", path: "/usr/bin/bash", user: "root", interactive: "true", cmd: "/usr/bin/bash ./custom_rule_filesystem_tools_general_files.py", service: "")'
