import sys


def main(ip: str, hostname: str):
    path = '/etc/hosts'
    is_hostname_existed = False
    f = open(path, 'r')
    line_list = f.readlines()
    f.close()

    # Re-open file here
    f2 = open(path, 'w')
    for line in line_list:
        if hostname in line or ip in line:
            line = line.replace(line, f'{ip} {hostname}\n')
            is_hostname_existed = True
        f2.write(line)
    if not is_hostname_existed:
        f2.write(f'{ip} {hostname}\n')
    f2.close()


if __name__ == '__main__':
    ip = str(sys.argv[1])
    hostname = str(sys.argv[2])
    main(ip=ip, hostname=hostname)
