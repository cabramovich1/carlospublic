#!/bin/bash
echo "killing leftover mock_service process if there is one"
kill -9 $(pgrep -d' ' -f /tmp/mock_service/main.py)
echo "installing python3-venv"
sudo apt-get install python3-venv -y
echo "creating venv"
python3 -m venv /tmp/mock_venv
echo "activating venv"
source /tmp/mock_venv/bin/activate
echo "installing requirements.txt"
pip install -r /tmp/mock_service/requirements.txt
echo "running mock_service process on port $1"
nohup python /tmp/mock_service/main.py $1 2>/dev/null 1>/dev/null &