#!/usr/bin/env python3

import json
import sys
from time import sleep
import subprocess

from flask import Flask, Response, request, render_template, make_response, jsonify, stream_with_context

app = Flask(__name__, template_folder='')


@app.route('/get_endpoint', methods=['GET'])
def get_index():
    try:
        content = request.get_json()
    except:
        content = 'nothing of json content was sent'
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/post_endpoint', methods=['POST'])
def post_index():
    try:
        content = request.get_json()
    except:
        content = 'nothing of json content was sent'
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/put_endpoint', methods=['PUT'])
def put_index():
    try:
        content = request.get_json()
    except:
        content = 'nothing of json content was sent'
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/patch_endpoint', methods=['PATCH'])
def patch_index():
    try:
        content = request.get_json()
    except:
        content = 'nothing of json content was sent'
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/info_leak', methods=['GET'])
def info_leak():
    bashCmd = ["cat", "/etc/passwd"]
    process = subprocess.Popen(bashCmd, stdout=subprocess.PIPE)
    output, error = process.communicate()
    print(output)
    return output


@app.route('/csrf', methods=['GET'])
def csrf():
    resp = make_response(render_template('index.html'))
    resp.set_cookie('star', 'wars')
    return resp


@app.route('/get_status_code/<status_code>', methods=['GET'])
def get_status_code(status_code):
    try:
        status_code = int(status_code)
        return Response(response="ok", status=status_code, mimetype='text/plain')
    except:
        return Response(response="mock service failed to parse request", status=500)


@app.route('/post_status_code', methods=['POST'])
def post_status_code():
    try:
        content = request.get_json()
        status_code = int(content['status_code'])
        return Response(response=f'received status code {status_code}', mimetype='text/plain', status=status_code)
    except:
        return Response(response="mock service failed to parse request", status=500)


@app.route('/get_timeout/<time>', methods=['GET'])
def get_timeout(time):
    print(f"sleeping for {time} seconds")
    sleep(time)
    return Response(response="ok", status=200)


@app.route('/get_echo/<data_type>/<data>', methods=['GET'])
def get_echo(data_type, data):
    if data_type == 'json':
        mimetype = 'application/json'
        response = json.dumps({'data': data})
    elif data_type == 'text':
        mimetype = 'text/plain'
        response = data
    elif data_type == 'xml':
        mimetype = 'application/xml'
        response = '<xml>\n\t<data>{}</data>\n</xml>'.format(data)
    else:
        mimetype = 'text/plain'
        response = 'mock service failed to parse request - data type {} not recognized'.format(data_type)
    return Response(response=response, status=200, mimetype=mimetype)


@app.route('/get_echo_header/<header_key>/<header_val>', methods=['GET'])
def get_echo_header(header_key, header_val):
    response = make_response(render_template('index.html'))
    response.headers[header_key] = header_val
    return response


# API Discovery endpoints


@app.route('/api_observation/buyers', methods=['get', 'post'])
def api_observation_buyers():
    ok_message = 'OK'
    return Response(response=json.dumps(ok_message), status=200, mimetype='application/json')


@app.route('/api_observation/merchants', methods=['post', 'delete', 'patch', 'head', 'options'])
def api_observation_merchants():
    ok_message = 'OK'
    return Response(response=json.dumps(ok_message), status=200, mimetype='application/json')


@app.route('/api_observation/merchants/small', methods=['get', 'post', 'put', 'patch', 'delete', 'patch', 'head',
                                                        'options'])
def api_observation_merchants_small():
    ok_message = 'OK'
    return Response(response=json.dumps(ok_message), status=200, mimetype='application/json')


@app.route('/api_observation/merchants/big', methods=['delete'])
def api_observation_merchants_big():
    ok_message = 'OK'
    return Response(response=json.dumps(ok_message), status=200, mimetype='application/json')


@app.route('/api_observation/custom_path/<path>', methods=['get', 'post', 'delete', 'patch', 'head', 'options'])
def api_observation_custom_path(path):
    ok_message = f'OK, path is {path}'
    return Response(response=json.dumps(ok_message), status=200, mimetype='application/json')


@app.route('/get_attacker_ip', methods=['GET'])
def get_attacker_ip():
    """
    @return: Return the ip of the request's sender
    """
    if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
        res = request.environ['REMOTE_ADDR']
    else:
        res = request.environ['HTTP_X_FORWARDED_FOR']
    return Response(response=res, status=200, mimetype='application/json')


@app.route("/site_map", methods=['GET'])
def site_map():
    """
    @return: Return a list of supported api routes and their supported http methods
    """
    routes = {}
    for r in app.url_map._rules:
        routes[r.rule] = {}
        routes[r.rule]["methods"] = str(r.methods)
    routes.pop("/static/<path:filename>")
    return jsonify(routes)


@app.route('/api_protection/<path>/<params>', methods=['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS', 'HEAD', 'PATCH'])
def api_protection(path, params):
    return Response(response='OK', status=200, mimetype='application/json')


@app.route('/echo_all_received_headers', methods=['GET'])
def echo_all_received_headers():
    """
    @return: Return all received headers with prefix "Received-" in response json body and response headers
    """
    response = make_response()
    response_dict = {}
    for key, val in request.headers.items():
        header_key = f'Received-{key}'
        response_dict[header_key] = val
        response.headers[header_key] = val
    response.data = json.dumps(response_dict)
    return response


@app.route('/get_attacker_data', methods=['GET'])
def get_attacker_data():
    """
    @return: Return attacker data if available: REMOTE_ADDR, X-Forwarded-For and X-Forwarded-Host in response body
    """
    response = make_response()
    response_dict = {'Remote-Addr': request.environ.get('REMOTE_ADDR', 'not available'),
                     'X-Forwarded-For': request.headers.get('X-Forwarded-For', 'not available'),
                     'X-Forwarded-Host': request.headers.get('X-Forwarded-Host', 'not available')}
    response.data = json.dumps(response_dict)
    return response


@app.route('/transfer_encoding/chunked', methods=['GET'])
def get_transfer_encoding_response():
    def generate():
        yield '4\r\n'
        yield 'Wiki\r\n'
        yield '0\r\n'
        yield '\r\n'

    return Response(stream_with_context(generate()))


@app.route('/post_echo', methods=['POST'])
def post_echo():
    try:
        content = request.get_json()
    except:
        content = json.dumps({'response': 'invalid_json'})
    response = make_response()
    response.data = json.dumps(content)
    return response


if __name__ == '__main__':
    port = ''
    ssl = ''

    try:
        port = int(sys.argv[1])
        print(f"Received port: {port}")
        # ssl = bool(strtobool(sys.argv[2]))
        ssl = str(sys.argv[2])
        print(f"Received ssl: {ssl}")
    except Exception as e:
        print(f"Error in mock service init: {e}")
        if not port:
            port = 8081
        ssl = ''

    if ssl == "host":
        print("Run mock service host as HTTPS!")
        path = "/tmp/mock_service_https/mock_service/mock_cert"
        app.run(ssl_context=(f'{path}/cert.cert', f'{path}/key.key'), host='0.0.0.0', use_reloader=True, port=port)
    elif ssl == "container":
        print("Run mock service container as HTTPS!")
        path = "/app/mock_cert"
        app.run(ssl_context=(f'{path}/cert_con.cert', f'{path}/key_con.key'),
                host='0.0.0.0', use_reloader=True, port=port)
    else:
        app.run(debug=True, host='0.0.0.0', use_reloader=True, port=port)