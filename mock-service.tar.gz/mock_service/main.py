import json
import sys
from time import sleep
import subprocess

from flask import Flask, Response, request, render_template, make_response


app = Flask(__name__, template_folder='')


@app.route('/get_endpoint', methods=['GET'])
def get_index():
    content = request.get_json()
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/post_endpoint', methods=['POST'])
def post_index():
    content = request.get_json()
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/put_endpoint', methods=['PUT'])
def put_index():
    content = request.get_json()
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/patch_endpoint', methods=['PATCH'])
def patch_index():
    content = request.get_json()
    print(f'This is the incoming request content: {content}')
    print(f'Headers content is: {request.headers}')
    return render_template('index.html'), {'Content-Type': 'text/html'}


@app.route('/info_leak', methods=['GET'])
def info_leak():
    bashCmd = ["cat", "/etc/passwd"]
    process = subprocess.Popen(bashCmd, stdout=subprocess.PIPE)
    output, error = process.communicate()
    print(output)
    return output


@app.route('/csrf', methods=['GET'])
def csrf():
    resp = make_response(render_template('index.html'))
    resp.set_cookie('star', 'wars')
    return resp


@app.route('/get_status_code/<status_code>', methods=['GET'])
def get_status_code(status_code):
    try:
        status_code = int(status_code)
        return Response(response="ok", status=status_code, mimetype='text/plain')
    except:
        return Response(response="mock service failed to parse request", status=500)


@app.route('/get_timeout', methods=['GET'])
def get_timeout():
    print("sleeping")
    sleep(120)
    return Response(response="ok", status=200)


@app.route('/get_echo/<data_type>/<data>', methods=['GET'])
def get_echo(data_type, data):
    if data_type == 'json':
        mimetype = 'application/json'
        response = json.dumps({'data': data})
    elif data_type == 'text':
        mimetype = 'text/plain'
        response = data
    elif data_type == 'xml':
        mimetype = 'application/xml'
        response = '<xml>\n\t<data>{}</data>\n</xml>'.format(data)
    else:
        mimetype = 'text/plain'
        response = 'mock service failed to parse request - data type {} not recognized'.format(data_type)
    return Response(response=response, status=200, mimetype=mimetype)


@app.route('/get_echo_header/<header_key>/<header_val>', methods=['GET'])
def get_echo_header(header_key, header_val):
    response = make_response(render_template('index.html'))
    response.headers[header_key] = header_val
    return response


if __name__ == '__main__':
    try:
        port = int(sys.argv[1])
    except:
        port = 8081
    app.run(debug=True, host='0.0.0.0', use_reloader=True, port=port)
