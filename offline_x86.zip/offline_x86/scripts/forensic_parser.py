import datetime
from enum import Enum, unique, auto

import parser_utils



class ForensicParserException(Exception):
    """ Defined base exception class for various forensics parsers"""

    def __init__(self, parser_name, message):
        super().__init__("%s Parser Error: %s" % (parser_name.upper(), message))

@unique
class DefaultParserFields(Enum):
    """Default fields that should be added to all parsers results"""
    parse_time = auto()
    script_name = auto()


class ForensicParser:

    DEFAULT_DATA_NAME = "data"

    def __init__(self, input_file_path=None, script_name=None, **kwargs):
        self.__input_file_path = input_file_path
        self.__script_name = script_name
        self.__results_store: dict = dict()
        # Logger to be used by the derived parser classes
        self.logger = parser_utils.ForensicLogger.get_logger()
        self.logger.info(f"Running '{script_name}' forensic parser with kwargs={kwargs}.")
        self.kwargs = kwargs        

    def input_file(self):
        """Returns the input file path"""
        return self.__input_file_path

    def process(self):
        """ Performs input processing.
            This base class method just fills the default result fields.
            The derived classes are expected to override this method and call it first
            in the overriding method"""

        self.__add_default_fields()

    def script_name(self):
        return self.__script_name

    def get_results(self):
        return self.__results_store

    def _result_meta_data(self):
        """  Protected method: to be called by the derived classes only.
            Returns meta-data section of the results store.
            Initializes the meta-data if it's not yet initialized.
            The final result format is expected to be:
            '{
              "<parser-name>": {
                    "data": {
                        #### Data section ####
                        "data-name1": [
                            ....
                        ]
                        "data-name2": [
                        ...
                        ]
                    }
                    ####  Meta-data section ####
                    "parse_time": ...
                    "<additional-field>": ...
              }
            }'
        """

        if not self.script_name():
            raise ForensicParserException("ForensicParser", "Script name is not defined. Cannot initialize script results meta-data")

        script_name_wrapper = self.__results_store.get(self.script_name())
        if not script_name_wrapper:
            self.__results_store[self.script_name()] = dict()
            script_name_wrapper = self.__results_store[self.script_name()]
        return script_name_wrapper


    def _result_data(self):
        """ Protected method: to be called by the derived classes only.
            Returns the result 'data' section.
            Initializes the 'data' section if it's not yet initialized .
            The final result format is expected to be:
            '{
              "<parser-name>": {
                    "data": {
                        #### Data section ####
                        "data-name1": [
                            ....
                        ]
                        "data-name2": [
                        ...
                        ]
                    }
                    ####  Meta-data section ###
                    "parse_time": ...
                    "<additional-field>": ...
              }
            }'
            """

        script_name_wrapper = self._result_meta_data()
        results_data = script_name_wrapper.get(ForensicParser.DEFAULT_DATA_NAME)
        if not results_data:
            script_name_wrapper[ForensicParser.DEFAULT_DATA_NAME] = dict()
            results_data = script_name_wrapper[ForensicParser.DEFAULT_DATA_NAME]
        return results_data


    def __add_default_fields(self):
        """Adds default parser results fields"""

        # parse-time as UTC time
        time_now = datetime.datetime.now().astimezone(datetime.timezone.utc)
        self._result_meta_data()[DefaultParserFields.parse_time.name] = parser_utils.datetime_to_unix_timestamp_ms(time_now)
    
    def cpu_throttled(self, items):
        max_cpu = self.kwargs.get("max_cpu")
        if max_cpu:
            self.cpu_throttler = parser_utils.CpuThrottler(max_cpu)
        else:
            self.cpu_throttler = None
        for item in items:
            if self.cpu_throttler:
                self.cpu_throttler.cpu_throttle()
            yield item

    def __del__(self):
        self.logger.info(f"Finished collecting {self.__script_name} data")
