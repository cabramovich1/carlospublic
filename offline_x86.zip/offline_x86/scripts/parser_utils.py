import time
import glob
import contextlib
from functools import lru_cache
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass
from pathlib import Path
from collections.abc import MutableMapping
import hashlib
import os
import sys
from enum import Enum
import logging
from logging.handlers import RotatingFileHandler
import uuid
import socket
import codecs
import struct
import subprocess
import re
import ipaddress
import psutil
import stat
from decimal import Decimal
from fractions import Fraction
if psutil.WINDOWS:
    import pytz
    import tzlocal
    import win32api
    import win32file
    import win32con
    import win32security
    import pywintypes

import md5lib


MILLISECONDS_IN_SEC = 1000
LOG_TO_CONSOLE = False


class RotatingFileHandlerWithPermissions(RotatingFileHandler):
    """A looger rotating file handler that also chmod's the files.    
        new file be created.
    """

    DEFAULT_FILE_ACCESS = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP
   
    def _open(self):
        """
        Open the current base file with the (original) mode and encoding.
        Return the resulting stream.
        That method will be call on every creation of the log file, 2 cases:
        1. First creation.
        2. After rotation when the old file renamed and a new file created
        """
        ret_val = super()._open()
        
        # We do our best to change the file permissions on Linux / MAC. 
        # There are some cases that Sprot will block the chmod like when user 
        # is running a script from the tenant UI. 
        if RotatingFileHandlerWithPermissions.is_allow_to_change_permissions():
            try:                
                os.chmod(self.baseFilename, self.DEFAULT_FILE_ACCESS)
            except PermissionError:
                pass

        return ret_val
    
    @staticmethod
    def is_allow_to_change_permissions():
        if psutil.LINUX or psutil.MACOS:
            return os.environ.get('script_type', '').lower() != 'scriptExecution'.lower()
        return False

    def rotate(self, source, dest):
        """Set the permissions to the rotated file"""
        super().rotate(source, dest)
        if RotatingFileHandlerWithPermissions.is_allow_to_change_permissions():
            # The rotated file name
            try:                
                os.chmod(dest, self.DEFAULT_FILE_ACCESS)
            except PermissionError:
                pass


class ForensicLogger:
    """
    Manages the Forensics scripts modules logging
    """

    class ActionIdFilter(logging.Filter):

        def __init__(self):
            super().__init__()
            # Tries to get the action id from the environment. If not found,
            # generates a random action id
            self.action_id = os.environ.get('traps_action_id', str(uuid.uuid4()))

        def filter(self, record):
            record.action_id = self.action_id
            return True

    LOGGER_NAME = "forensic"
    LOG_FILE_NAME = "forensic_scripts.log"
    LOG_LEVEL_ENV_NAME = "script_log_level"  # Env variable name for log level
    LOG_LEVEL_PAYLOAD_ENV_NAME = "log_level"  # Env variable name for log level
    LOG_PATH_ENV_NAME = "log_path"  # Env variable name to define log file location
    DEFAULT_LOG_LEVEL = logging.INFO
    DISABLED_LOG_LEVEL = -1

    __initialized = False  # Records if logger initialization happened

    @staticmethod
    def get_log_dir():
        log_dir = os.environ.get(ForensicLogger.LOG_PATH_ENV_NAME, None)
        return log_dir or os.getcwd()

    @classmethod
    def __get_log_path(cls):
        return os.path.join(cls.get_log_dir(), ForensicLogger.LOG_FILE_NAME)

    @staticmethod
    def __get_log_level():
        """
        Reads the log level from the environment variable, if defined.
        If no environment variable is defined, or in case of an error,
        sets to the default log level.
        :return: the log level
        """
        LOGGERHL_LEVELS = {
            "1": logging.FATAL,
            "2": logging.CRITICAL,
            "3": logging.ERROR,
            "4": logging.WARNING,
            "5": logging.INFO, # Notice
            "6": logging.INFO,
            "7": logging.DEBUG,
            "8": logging.NOTSET # Trace
        }

        # First try to set the log level by scripts dedicated environment var
        # If not exist / invalid try to get it from Payload log level environment
        # variable
        log_level = None
        for env_var in (ForensicLogger.LOG_LEVEL_ENV_NAME, ForensicLogger.LOG_LEVEL_PAYLOAD_ENV_NAME):
            log_level_env = os.environ.get(env_var)
            
            # On all cases log level is a numeric value
            if log_level_env and log_level_env.isnumeric():

                # There are 2 options for a valid environment variable.
                #   1. The Payload already sends the value after conversion from
                #      agent value to Python logging value.
                #   2. The other option is that it was set by env var on the
                #      system using agent values (1 to 6) so need conversion to
                #      python logging values (10, 20, 30, ...)

                # using the agent log level value 1 <= val <= 6
                if log_level_env in LOGGERHL_LEVELS:
                    log_level = LOGGERHL_LEVELS.get(log_level_env)
                    break

                # Python log level values 0, 10, 20,....
                elif int(log_level_env) in LOGGERHL_LEVELS.values():
                    log_level = int(log_level_env)
                    break

                else:
                    print(f"Invalid Log level: '{log_level_env}'" 
                          f" from environment variable: '{env_var}'")
       
        # Default log level in case we could not resolve from environment variables
        if log_level is None:
            log_level = ForensicLogger.DEFAULT_LOG_LEVEL

        return log_level

    @staticmethod
    def is_log_disabled(log_level: int):
        """
        :param log_level: log level to check
        :return: True if the given log level is a disabled log level
        """
        return log_level == ForensicLogger.DISABLED_LOG_LEVEL

    @staticmethod
    def get_logger():
        """
        Initializes and returns the logger.
        If the logger is already initialized just returns it.
        This function is to be called to get the logger instance.
        Always the same initialized logger instance will be returned.
        :return: the initialized logger
        """

        log = logging.getLogger(ForensicLogger.LOGGER_NAME)
        if ForensicLogger.__initialized:
            return log

        log_level = ForensicLogger.__get_log_level()
        if ForensicLogger.is_log_disabled(log_level):
            log.setLevel(ForensicLogger.DEFAULT_LOG_LEVEL)
            logging.disable(logging.CRITICAL)
        else:
            log.setLevel(log_level)

        log.propagate = False

        log_format = '%(asctime)s|%(levelname)-8.8s|%(process)d:' \
                     '(%(threadName)-12s)|%(module)s|ACTION_ID: ' \
                     '%(action_id)-31s|%(message).10000s'

        # In windows we must set format times with local timezone because
        # pytsk3 will override the default usage of the time zone
        if psutil.WINDOWS:
            formatter = LogLocalTimeFormatter(log_format)
        else:
            formatter =  logging.Formatter(log_format)
        formatter.datefmt = '%Y/%m/%d %H:%M:%S'

        fh = RotatingFileHandlerWithPermissions(ForensicLogger.__get_log_path(),
                                 maxBytes=10000000,
                                 backupCount=5,
                                 encoding="utf-8")
        fh.setFormatter(formatter)
        log.addHandler(fh)
        action_id = ForensicLogger.ActionIdFilter()
        log.addFilter(action_id)
        
        # Add consoile logger for devel
        if LOG_TO_CONSOLE:
            ch = logging.StreamHandler()
            ch.setLevel(logging.DEBUG)
            log.addHandler(ch)

        ForensicLogger.__initialized = True

        print(f"'{ForensicLogger.LOGGER_NAME}' logger initialized. Action id: {action_id.action_id}, log file path: {ForensicLogger.__get_log_path()}")
        return log


    @staticmethod
    def is_debug(logger):
        """ Convenience method - returns True if the given logger's level is Debug"""
        return logger.level == logging.DEBUG

    @staticmethod
    def is_info(logger):
        """ Convenience method - returns True if the given logger's level is Info"""
        return logger.level == logging.INFO


class LogLocalTimeFormatter(logging.Formatter):
    """override logging.Formatter to use an aware datetime object.
    We need to do that because when we import the pytsk3 it sets the default
    time zone to UTC instead of the system timezone and we get different times
    than the other logs which will use the local time zone.
    For more information at related issue:
    https://jira-hq.paloaltonetworks.local/browse/CPATR-15215
    """
    def converter(self, timestamp):
        # Create datetime in UTC
        dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        # Change datetime's timezone
        return dt.astimezone(pytz.timezone(tzlocal.get_localzone_name()))

    def formatTime(self, record, datefmt):
        dt = self.converter(record.created)
        return dt.strftime(datefmt)


def format_value(value):
    """ Return a numric value with separator, or the original value if it's not numeric. """
    try:
        if isinstance(value, (int, float, Decimal, Fraction)):
            return "{:,}".format(value)
        else:
            return value
    except Exception:
        return value

@dataclass
class Hashes:
    md5: str
    sha1: str
    sha256: str


@lru_cache(maxsize=10000)
def calculate_hashes(file_path):
    # calculate hash for local files existing files
    if file_path.startswith("\\\\") or not os.path.isfile(file_path):
        return None

    md5 = md5lib.md5(usedforsecurity=False)
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()

    try:
        with open(file_path, "rb") as fin:
            for chunk in iter(lambda: fin.read(4096), b""):
                md5.update(chunk)
                sha1.update(chunk)
                sha256.update(chunk)
    except OSError:
        return None
    except IOError:
        return None

    return Hashes(md5=md5.hexdigest(), sha1=sha1.hexdigest(), sha256=sha256.hexdigest())


@contextlib.contextmanager
def create_file_ctx(path, disposition, access_mask, flags, sharing):
    """
    CreateFileA context manager wrapper.
    """
    handle = None
    try:
        handle = win32file.CreateFile(path,
                                      access_mask,
                                      sharing,
                                      None,
                                      disposition,
                                      flags,
                                      None)

        yield handle

    except:
        raise

    finally:
        if handle is not None:
            win32api.CloseHandle(handle)


def get_epoch_time() -> datetime:
    return datetime.fromtimestamp(0, timezone.utc)


def datetime_to_unix_timestamp_ms(dt: datetime):
    """ Converts the given time into the timestamp since Unix epoch in milliseconds
        Returns None if conversion failed"""

    if dt is None:
        return None

    if dt < get_epoch_time():
        # The provided time is invalid
        return None
    try:
        return int (dt.timestamp() * MILLISECONDS_IN_SEC)
    except Exception as e:
        print(f"Error: failed converting time: {str(datetime)} to timestamp. Error: {str(e)}")
        return None


def get_now_time_ms():
    time_now = datetime.now().astimezone(timezone.utc)
    return datetime_to_unix_timestamp_ms(time_now)


def str_time_to_unix_timestamp_ms(str_time: str, time_format: str, suppress_warning=False):
    """ Converts a string to Unix epoch timestamp in milliseconds
        time_format is the time representation format as defined in datetime.strptime()
        Assumes the string time is in UTC timezone.
        Returns None if conversion failed
        If suppress_warning is True - will not issue a warning on conversion failure
        """

    logger = ForensicLogger.get_logger()
    if str_time is None:
        return None

    if type(str_time) is not str or type(time_format) is not str:
        if not suppress_warning:
            logger.warning(f"Cannot convert string to time, incompatible arguments types "
                           f"({type(str_time)},{type(time_format)}). Expecting str arguments")
        return None

    if len(str_time) == 0:
        return None

    try:
        dt = datetime.strptime(str_time, time_format).replace(tzinfo=timezone.utc)  # Converts to datetime object in UTC timezone
        return datetime_to_unix_timestamp_ms(dt)
    except Exception:
        if not suppress_warning:
            logger.warning(f"Failed converting string time: {str_time} to timestamp.")
        return None


def filetime_to_datetime(file_time: int):
    """ Converts Win32 FILETIME into daytime object.
        Returns None in case of conversion error.
        FILETIME Contains a 64-bit value representing the number of 100-nanosecond
        intervals since January 1, 1601 (UTC) """

    if file_time is None:
        return None
    try:
        dt = int(file_time) # doing the cast in case file_time is not int
        micro_sec = dt / 10 # (X100/1000) to convert to micro-seconds
        # Converts January 1, 1601 to UTC and then adds the delta
        return datetime(1601, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=micro_sec)

    except Exception as e:
        print(f"Error: failed converting FILETIME: {file_time} to datetime")
        return None


def filetime_to_unix_timestamp_ms(file_time: int):
    """ Converts Win32 FILETIME into unix timestamp in milliseconds
        Returns None in case of conversion error """

    dt = filetime_to_datetime(file_time)
    return datetime_to_unix_timestamp_ms(dt)

# this functions was taken from python source - only added environ param
# to support expanding custom vars (rather than the hardcoded os.environ)
def expandvars(path, environ):
    """Expand shell variables of the forms $var, ${var} and %var%.

    Unknown variables are left unchanged."""
    assert isinstance(environ, dict) or isinstance(environ, MutableMapping), "invalid environ"

    path = os.fspath(path)
    if isinstance(path, bytes):
        if b'$' not in path and b'%' not in path:
            return path
        import string
        varchars = bytes(string.ascii_letters + string.digits + '_-', 'ascii')
        quote = b'\''
        percent = b'%'
        brace = b'{'
        rbrace = b'}'
        dollar = b'$'
        # environ = getattr(os, 'environb', None)
    else:
        if '$' not in path and '%' not in path:
            return path
        import string
        varchars = string.ascii_letters + string.digits + '_-'
        quote = '\''
        percent = '%'
        brace = '{'
        rbrace = '}'
        dollar = '$'
        # environ = os.environ
    res = path[:0]
    index = 0
    pathlen = len(path)
    while index < pathlen:
        c = path[index:index+1]
        if c == quote:   # no expansion within single quotes
            path = path[index + 1:]
            pathlen = len(path)
            try:
                index = path.index(c)
                res += c + path[:index + 1]
            except ValueError:
                res += c + path
                index = pathlen - 1
        elif c == percent:  # variable or '%'
            if path[index + 1:index + 2] == percent:
                res += c
                index += 1
            else:
                path = path[index+1:]
                pathlen = len(path)
                try:
                    index = path.index(percent)
                except ValueError:
                    res += percent + path
                    index = pathlen - 1
                else:
                    var = path[:index]
                    try:
                        value = environ[var]
                    except KeyError:
                        value = percent + var + percent
                    res += value
        elif c == dollar:  # variable or '$$'
            if path[index + 1:index + 2] == dollar:
                res += c
                index += 1
            elif path[index + 1:index + 2] == brace:
                path = path[index+2:]
                pathlen = len(path)
                try:
                    index = path.index(rbrace)
                except ValueError:
                    res += dollar + brace + path
                    index = pathlen - 1
                else:
                    var = path[:index]
                    try:
                        value = environ[var]
                    except KeyError:
                        value = dollar + brace + var + rbrace
                    res += value
            else:
                var = path[:0]
                index += 1
                c = path[index:index + 1]
                while c and c in varchars:
                    var += c
                    index += 1
                    c = path[index:index + 1]
                try:
                    value = environ[var]
                except KeyError:
                    value = dollar + var
                res += value
                if c:
                    index -= 1
        else:
            res += c
        index += 1
    return res

def get_volume_information(path):
    if not path:
        return {}
    mount_point = volume_identifier = volume_serial = volume_name = None
    try:
        mount_point = win32file.GetVolumePathName(path)
        volume_identifier = win32file.GetVolumeNameForVolumeMountPoint(mount_point)
        volume_serial = win32api.GetVolumeInformation(mount_point)[1]
        volume_name = win32api.GetVolumeInformation(mount_point)[0]
    except Exception:
        pass

    return {
        "volume_mount_point": mount_point,
        "volume_identifier": volume_identifier,
        "volume_serial": volume_serial,
        "volume_name": volume_name
    }


def resolve_volume_to_drive_path(path):
    '''
    A utility function to resolve a file path given with volume like:
    \\VOLUME{01d74011db633142-c8dbf8cc}\\myfolder\\m.txt
    into a drive path
    c:\\myfolder\\m.txt
    '''
    volume_info = get_volume_information(path)
    drive = volume_info['volume_mount_point'] # like c:\
    # Remove the volume part from the path
    path_no_volume = path.split('\\', 2)[2]
    resolved_path = drive + path_no_volume
    return resolved_path


def get_file_attributes(path):
    if not path:
        return None
    return win32file.GetFileAttributes(path)

def get_file_times(path):
    times = {
        "created": 0,
        "modified": 0,
        "accessed": 0
    }


    try:
        file_times = None
        with create_file_ctx(path, win32con.OPEN_ALWAYS,
                             win32con.GENERIC_READ, 0,
                             win32con.FILE_SHARE_READ) as file_handle:
            file_times = win32file.GetFileTime(file_handle)

        if file_times:
            times["created"] = datetime_to_unix_timestamp_ms(file_times[0])
            times["accessed"] = datetime_to_unix_timestamp_ms(file_times[1])
            times["modified"] = datetime_to_unix_timestamp_ms(file_times[2])

    except (FileNotFoundError, pywintypes.error):
        pass

    return times


def get_drive_type(path):
    return win32file.GetDriveType(path)


def json_default_serializer(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, Path):
        return str(obj)

    if isinstance(obj, bytes):
        # assume this is actually utf-8 string
        # otherwise, it should have been encoded in some way
        return obj.decode("utf-8")

    if isinstance(obj, datetime):
        return datetime_to_unix_timestamp_ms(obj)

    raise TypeError ("Type %s not serializable" % type(obj))


def enum_value_to_name_dict(enum_type: Enum):
    """ Returns reverse mapping dictionary of enum values to enum names """
    return {e.value: e.name for e in enum_type}


class FileMultiHasher:
    """ Calculates md5, sha1 or sha256 of a file """

    def __init__(self, md5: bool=False, sha1: bool=False, sha256: bool=True, buf_size_bytes=65536):
        """ Initializes the hashers according to the provided hashing methods:
            md5, sha1 or sha256. All methods can be used separately or together.
            buf_size_bytes - the size of the buffer used in file reading """

        self.__md5 = md5lib.md5(usedforsecurity=False) if md5 else None
        self.__sha1 = hashlib.sha1() if sha1 else None
        self.__sha256 = hashlib.sha256() if sha256 else None
        self.__buf_size_bytes: int = buf_size_bytes

    def process_file(self, file_path: str):
        """ Reads the provided file in chunks and computes the required hashes.
            Note, that repeated calls to this function without calling reset() method will
            cause to results' accumulation"""

        with open(file_path, 'rb') as f:
            while True:
                data = f.read(self.__buf_size_bytes)
                if not data:
                    break
                if self.__md5:
                    self.__md5.update(data)
                if self.__sha1:
                    self.__sha1.update(data)
                if self.__sha256:
                    self.__sha256.update(data)

    def reset(self):
        """ Resets the hasher state"""

        self.__md5 = md5lib.md5(usedforsecurity=False) if self.__md5 else None
        self.__sha1 = hashlib.sha1() if self.__sha1 else None
        self.__sha256 = hashlib.sha256() if self.__sha256 else None

    def md5(self):
        return self.__md5.hexdigest() if self.__md5 else None

    def sha1(self):
        return self.__sha1.hexdigest() if self.__sha1 else None

    def sha256(self):
        return self.__sha256.hexdigest() if self.__sha256 else None


def is_win8_os():
    """ Returns True if this OS is one of: Win8/Win8.1 or Windows Server 2012/R2"""
    winver = sys.getwindowsversion()
    return winver.major == 6 and winver.minor > 1


def is_win10_os():
    """ Returns True is this OS is one of: Win10/Windows Server 2016/2019"""
    winver = sys.getwindowsversion()
    return winver.major == 10

def get_win_build_number():
    winver = sys.getwindowsversion()
    return winver.build

def get_windows_drive_name(path: str) -> str:
    path_list = os.path.splitdrive(path)
    if not path_list or len(path_list) != 2:
        return None
    return path_list[0]

def remove_empty_dict_values(entry: dict) -> dict:
    """
    Returns a new dict without the entries containing empty values.
    Empty value is a None value or empty string.
    Note: 0 int value is not considered empty.
    :param entry: the dict to process for empty values
    :return:
    """
    return {k: v for k, v in entry.items() if not (v is None or type(v)==str and len(v)==0)}


def get_name_from_sid(str_sid: str, default_name=None) -> str:
    """
    Retrieve the name of the account for given SID and the name of the first domain on which this SID is found.
    :param str_sid: The SID as string
    :param default_name: The string that is used if account is not found for given SID, "N/A" for example
    :return: Readable string representation in the form domain\\username.
    """
    sid = None
    try:
        sid = win32security.ConvertStringSidToSid(str_sid)
        name, domain, _ = win32security.LookupAccountSid(None, sid)
        return domain + "\\" + name
    except Exception as e:
        ForensicLogger.get_logger().warning(f"Could not lookup user name for sid: '{sid}'. "
                                            f"Default name: {default_name if default_name else 'None'}. err: {e}")
        if default_name:
            return default_name
        return None

def get_user_sid_from_username(username):
    '''Return the user sid from  from a suer name'''
    try:
        sid_obj, _, _ = win32security.LookupAccountName(None, username)
        return win32security.ConvertSidToStringSid(sid_obj)
    except:
        return None

def binary_sid_to_string_sid(binary_sid) -> str:
    # Original form Source: https://github.com/google/grr/blob/master/grr/parsers/wmi_parser.py
    """Converts a binary SID to its string representation.
     https://msdn.microsoft.com/en-us/library/windows/desktop/aa379597.aspx
    The byte representation of an SID is as follows:
      Offset  Length  Description
      00      01      revision
      01      01      sub-authority count
      02      06      authority (big endian)
      08      04      subauthority #1 (little endian)
      0b      04      subauthority #2 (little endian)
      ...
    Args:
      binary_sid: A byte array.
    Returns:
      SID in string form.
    """
    if not binary_sid:
        return ""
    sid = codecs.decode(binary_sid, "hex")
    str_sid_components = [sid[0]]
    sid_str = ""
    # Now decode the 48-byte portion
    if len(sid) >= 8:
        sub_authority_count = sid[1]
        identifier_authority = struct.unpack(">H", sid[2:4])[0]
        identifier_authority <<= 32
        identifier_authority |= struct.unpack(">L", sid[4:8])[0]
        str_sid_components.append(identifier_authority)
        start = 8
        for i in range(sub_authority_count):
            authority = sid[start:start + 4]
            if not authority:
                break
            if len(authority) < 4:
                ForensicLogger.get_logger().error(f"In binary SID component {i} has been truncated. "
                                                  f"Expected 4 bytes, found {len(authority)}: ({authority})")
                return sid_str
            str_sid_components.append(struct.unpack("<L", authority)[0])
            start += 4
            sid_str = "S-%s" % ("-".join([str(x) for x in str_sid_components]))
    return sid_str


def ole_timestamp_to_unix_timestamp_ms(hex_timestamp):
    """ Converts a hex encoded OLE time to Unix epoch timestamp in milliseconds.
    Returns None if conversion failed"""

    try:
        td, ts = str(struct.unpack("<d", hex_timestamp)[0]).split(".")
        date_time = datetime(1899, 12, 30, 0, 0, 0, tzinfo=timezone.utc) + timedelta(days=int(td), seconds=86400 * float("0.{}".format(ts)))
        return datetime_to_unix_timestamp_ms(date_time)
    except:
        ForensicLogger.get_logger().exception(f"Failed to convert binary timestamp to epoc time.")
    return None


def binary_hex_to_string(binary_hex):
    """Takes in a binary blob hex characters and does its best to convert it to a readable string.
       Works great for UTF-16 LE, UTF-16 BE, ASCII like data. Otherwise return it as hex.
    """
    converted_str = binary_hex
    try:
        hex_bytes = codecs.decode(binary_hex, "hex")
    except:
        hex_bytes = binary_hex
    try:
        if re.match(b'^(?:[^\x00]\x00)+\x00\x00$', hex_bytes):
            converted_str = hex_bytes.decode("utf-16-le").strip("\x00")
        elif re.match(b'^(?:\x00[^\x00])+\x00\x00$', hex_bytes):
            converted_str = hex_bytes.decode("utf-16-be").strip("\x00")
        else:
            converted_str = hex_bytes.decode("latin1").strip("\x00")
    except:
        try:
            converted_str = "" if not converted_str else codecs.decode(converted_str, "latin-1")
        except:
            converted_str = binary_hex
    return converted_str


class CIDict(MutableMapping):
    """
    Case-Insensitive dictionary, mapping string typed key to a value.
    Supports only str typed keys
    """
    def __init__(self, *args, **kwargs):
        self.store = dict()
        self.update(dict(*args, **kwargs))

    def __getitem__(self, key):
        return self.store[self._keytransform(key)]

    def __setitem__(self, key, value):
        self.store[self._keytransform(key)] = value

    def __delitem__(self, key):
        del self.store[self._keytransform(key)]

    def __iter__(self):
        return iter(self.store)

    def __len__(self):
        return len(self.store)

    def __str__(self):
        return str(self.store)

    def _keytransform(self, key: str):
        """
        Converts the key to uppercase
        """
        if not isinstance(key, str):
            raise ValueError(f"Expecting only str type keys while the actual key type is {type(key)}")
        return key.upper()


def win_filetime_binary_to_datetime(win_date_bin):
    """
    Converts a binary Windows FILETIME to a datetime
    Reference: https://github.com/brimorlabs/KStrike/blob/master/KStrike.py
    """

    try:
        windows_file_time = int(struct.unpack("<Q", win_date_bin)[0])
        return filetime_to_datetime(windows_file_time)
    except:
        return None


def binary2address(address):
    """
    Resolve a binary address ip to IPV4 / IPV6 from
    @address: the address in bytes
    Returns the address as string
    """

    # IPV6
    if len(address) > 10:
        try:
            ipaddr = ipaddress.IPv6Address(address)
            return str(ipaddr)
        except:
            return None

    # IPV4
    else:
        try:
            return str(ipaddress.IPv4Address(address))
        except:
            return None

def blob_to_string(binblob):
    """
    Takes in a binary blob hex characters and does its best to convert it to
    a readable string UTF-16.
    """

    value = None
    try:
        value = codecs.decode(binblob, "utf-16").replace('\x00', '')
    except:
        pass

    return value

def get_date_from_day_in_year(year, day_in_year):
    """Return date from a day number in particular year"""

    # Initializing start date
    year_first_day = datetime(int(year), 1, 1, tzinfo=timezone.utc)

    # Add number of days - 1 because we already in day 1
    return year_first_day + timedelta(days=day_in_year - 1)

def guid_from_bytes_string(bytes_string_guid):
    """
    Converts a string which represent a binary bytes of a guid to a guid string.
    The first 3 chunks of the UUID (the 8-4-4) are byte-order dependent because
    they represent integers. Fot that we must use the right byte order using
    little endian to create the guid right.
    More info here:
    https://neosmart.net/blog/2018/converting-a-binary-blob-guid-to-text-in-sql/
    """
    guid = None
    if bytes_string_guid:
        # First we create a uuid just to later get the bytes from it.
        u = uuid.UUID(bytes_string_guid)
        # Now we create the right uuid from the bytes but using the
        # right order (little endian)
        guid = str(uuid.UUID(bytes=u.bytes_le)) #
    return guid


def get_host_name():
    """
    Get host name.
    :return:
    """
    return socket.gethostname()


MAX_FIELD_SIZE_BYTES = 512 * 1024  # 512kb
def truncate_utf8_str_by_bytes_size(s: str, maxsize: int = MAX_FIELD_SIZE_BYTES) -> str:
    """A function to truncate a unicode utf-8 string by bytes length.
    The result string by bytes size will be in the range of:
    maxsize - 3 < truncated_string  <=  maxsize
    Thats because we may need to fix the bytes string by removing bytes from the
    end of the string in case we resized it in the the middle of a utf-8
    charcter which can be up to 4 bytes.    
    """
    UTF8_MAX_BYTES_PER_CHARACTER = 4
    bytes_str = s.encode('utf-8')    
    i = 0
    while i < UTF8_MAX_BYTES_PER_CHARACTER:
        try:
            return bytes_str[:maxsize-i].decode("utf-8")
        except UnicodeDecodeError:            
            i += 1

def truncate_str_value(value: str) -> str:
    truncated_value = truncate_utf8_str_by_bytes_size(value)
    if len(truncated_value) < len(value):
        ForensicLogger.get_logger().info(f"Record message size truncated from "
                                         f"{len(value)} to {len(truncated_value)}")
    return truncated_value

def get_script_output(script_name: str, *args):
    possible_script_locations = ["./", "./scripts/", "../scripts/", "../../scripts/"]
    script = ""
    for dir in possible_script_locations:
        if os.path.exists(dir + script_name):
            script = dir + script_name
            break
    if not script:
        raise Exception("Couldn't find swift script!!!")
    os.chmod(script, stat.S_IRWXU)

    args_list = list(args)
    args_list.insert(0, script)

    return subprocess.check_output(args_list)

def convert_chrome_timestamp_to_epoch_millis(t):
    if t == 0:
        return t

    return int(((t / 1000000) - 11644473600) * 1000)

def convert_unix_time_to_date(t):
    """ Converts apple timestamp(from 1.1.2001) into unix timestamp in milliseconds  """
    if t == 0:
        return t

    return int((t + 978307200) * 1000)

def convert_firefox_time_to_date(t):
    if t == 0:
        return t

    return int(t/1000)

def get_users_list():
    # Get a list of all directories in /Users
    all_users = os.listdir('/Users')
    # Exclude directories ".localized" and "Shared"
    users = [user for user in all_users if user not in (".localized", "Shared")]

    return users

class CpuThrottler():
    """
    The code here is copied from psutil + changes inspired by traps cpu_throttler.h
    """    
    def __init__(self, max_cpu_percent):
        self.max_cpu_percent = max_cpu_percent
        self._last_sys_cpu_times = None
        self._last_proc_cpu_times = None
        self._proc = psutil.Process()
        self._num_cpus = psutil.cpu_count() or 1
        self._timer = getattr(time, 'monotonic', time.time)

    def timer(self):
        return self._timer() * self._num_cpus

    def wait_until(self, end_time):
        while True:
            diff = (end_time - self.timer())
            if diff < 0:
                return  # In case end_datetime was in past to begin with
            time.sleep(diff / 2)
            if diff <= 0.1:
                return

    def cpu_throttle(self):
        self.logger = ForensicLogger.get_logger()
        st1 = self._last_sys_cpu_times
        pt1 = self._last_proc_cpu_times
        st2 = self.timer()
        pt2 = self._proc.cpu_times()
        if st1 is None or pt1 is None:
            self._last_sys_cpu_times = st2
            self._last_proc_cpu_times = pt2
            # Initial call doesn't have history so cant throttle
            return
    
        delta_proc = (pt2.user - pt1.user) + (pt2.system - pt1.system)
        delta_time = st2 - st1
        # If elapsed time is too small then cpu_percent won't have enough time to check the new cpu usage and will return 0
        if delta_time < 0.1:
            return
    
        # reset values for next call
        self._last_sys_cpu_times = st2
        self._last_proc_cpu_times = pt2
    
        # This is the utilization split evenly between all CPUs.
        # E.g. a busy loop process on a 2-CPU-cores system at this
        # point is reported as 50% instead of 100%.
        # This is how windows shows this so staying with this definition
        overall_cpus_percent = ((delta_proc / delta_time) * 100)
        if overall_cpus_percent < self.max_cpu_percent:
            return
    
        # Too much cpu usage - sleep until under threshold
        sleep_duration = delta_proc / (self.max_cpu_percent / 100)
        self.logger.info(f"going to sleep: PID: {os.getpid()}, sleep_duration: {sleep_duration}")
        sleep_time = self._last_sys_cpu_times + sleep_duration
        self.wait_until(sleep_time)
    
        # Reset state after sleep
        self._last_sys_cpu_times = self.timer()
        self._last_proc_cpu_times = self._proc.cpu_times()


def cpu_throttled_gen(items, max_cpu=None):
    if max_cpu:
        cpu_throttler = CpuThrottler(max_cpu)
    else:
        cpu_throttler = None
    for item in items:
        if cpu_throttler:
            cpu_throttler.cpu_throttle()
        yield item
    

def expand_wildcard_expression(wildcard_expression):
        all_files = []

        if wildcard_expression is None:
            return all_files

        for expression in wildcard_expression:
            all_files.extend(glob.glob(expression))

        return all_files


def main():
    logger = ForensicLogger.get_logger()
    logger.info(f"Hello this is INFO")
    logger.debug(f"This is DEBUG")
    logger.error("This is ERROR")
    additional_description = "Something bad happened"
    try:
        raise RuntimeError("Bad error")
    except:
        logger.exception(f"Error description: {additional_description}")


if __name__ == '__main__':
    main()
