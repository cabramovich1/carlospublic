from linux_forensics_parser import LinuxForensicsParser
import os
import datetime
from pathlib import Path
from filter_util import apply_filters

FILTERS_MAP = {
    "user_id": ("in_list", "uid"),
    "name": ("regex", "name"),
    "group_id": ("in_list", "gid"),
    }

class BodyfileParser(LinuxForensicsParser):
    """
    Parser for extracting hash information of executable files in Linux systems
    """
    def __init__(self, script_name='bodyfile', **kwargs):
        super().__init__(script_name=script_name, **kwargs)

    
    def create_profile(self):
        return self.uac_dir / "artifacts/bodyfile/bodyfile.yaml"

    
    def parse_artifacts_to_schema(self, extracted_dir):
        orig_dir = os.getcwd()
        specific_artifact_dir = Path(extracted_dir)
        bodyfiles = []
        if not os.path.exists(str(specific_artifact_dir)):
            self.logger.warning("No body_file files collected")
            return bodyfiles
        os.chdir(str(specific_artifact_dir /  'bodyfile'))
        try:
            # Collect process information and generate hash
            for body_file_path in os.listdir('.'):
                if body_file_path.endswith('.txt') :
                    self.parse_file(bodyfiles, body_file_path)
            return bodyfiles
        finally:
            os.chdir(orig_dir) 

    def parse_file(self, bodyfiles, body_file_path):
        with open(body_file_path, 'r') as bodyfile:
            for line_number, line in enumerate(bodyfile, 1):
                try:
                    # Skip empty lines
                    if not line.strip():
                        continue
                    
                    # Split the line by pipe character
                    parts = line.strip().split('|')
                    
                    # Check if we have the expected number of fields
                    if len(parts) < 11:
                        self.logger.error(f"Warning: Line {line_number} has fewer than expected fields: {line}")
                        continue
                    
                    # Extract values from the line
                    md5 = parts[0]
                    name = parts[1]
                    inode = LinuxForensicsParser.convert_to_int(parts[2])
                    mode = parts[3]
                    uid = LinuxForensicsParser.convert_to_int(parts[4])
                    gid = LinuxForensicsParser.convert_to_int(parts[5])
                    size = LinuxForensicsParser.convert_to_int(parts[6])

                    atime = parts[7]
                    mtime = parts[8]
                    ctime = parts[9]
                    crtime = parts[10] if len(parts) > 10 else ""
                    
                    # Convert timestamps to human-readable format (if they are valid)
                    atime_human = LinuxForensicsParser.convert_to_int(atime)
                    mtime_human = LinuxForensicsParser.convert_to_int(mtime)
                    ctime_human = LinuxForensicsParser.convert_to_int(ctime) 
                    brtime_human = LinuxForensicsParser.convert_to_int(crtime)
                    
                    # Create a bodyfile entity
                    entity = {
                        'md5': md5 if md5 != '0' else None,
                        'name': name,
                        'inode': inode,
                        'mode_as_string': mode,
                        'uid': uid,
                        'gid': gid,
                        'size': size,
                        #'atime': atime,
                        #'modified_time': mtime,
                        #'changed_time': ctime,
                        #'birth_time': crtime,
                        'atime': atime_human,
                        'mtime': mtime_human,
                        'ctime': ctime_human,
                        'crtime': brtime_human,
                        # Extract file type from mode
                        #'file_type': self.get_file_type(mode),
                        # Extract permissions from mode
                        #'permissions': mode[1:] if len(mode) > 1 else ""
                    }
                    #{"md5": "0", "name": "/", "inode": "2", "mode": "drwxr-xr-x", "uid": "0", "gid": "0", "size": "4096", "accessed_time": "2025-07-17 16:58:24", "modified_time": "2025-05-11 13:10:43", "changed_time": "2025-05-11 13:10:43", "birth_time": "1970-01-01 02:00:00"}
                    # Store in dictionary with file_path as key
                    bodyfiles.append(entity)
                    
                except Exception as e:
                    self.logger.error(f"Error parsing line {line_number}: {str(e)}")
                    self.logger.error(f"Line content: {line}")



    def get_file_type(self, mode):
        """
        Extract the file type from the mode field.
        """
        if not mode:
            return "Unknown"
            
        type_char = mode[0] if len(mode) > 0 else ""
        
        file_types = {
            '-': "Regular file",
            'd': "Directory",
            'l': "Symbolic link",
            'c': "Character device",
            'b': "Block device",
            'p': "Named pipe",
            's': "Socket"
        }
    
        return file_types.get(type_char, "Unknown")

    def get_filter_map(self):
        return FILTERS_MAP
    
    def timestamp_to_datetime(self, timestamp):
        """
        Convert Unix timestamp to human-readable datetime.
        """
        try:
            return datetime.datetime.fromtimestamp(int(timestamp)).strftime('%Y-%m-%d %H:%M:%S')
        except (ValueError, OverflowError, TypeError):
            return "Invalid timestamp"

    def print_collected_data(self, data):
        self.logger.info(f"\nFound {len(data)} unique file paths:")
        for file_path, bodyfile in data.items():
            self.logger.info(f"path: {file_path}, MD5: {bodyfile['md5']}, MODE : {bodyfile['mode']}, SIZE: {bodyfile['size']} , ATIME: {bodyfile['accessed_time']}" + 
                             f" MTIME: {bodyfile['modified_time']}, CTIME: {bodyfile['changed_time']}, BTIME: {bodyfile['birth_time']} ,TYPE: {bodyfile['file_type']}  ")
            
def parse(**input):
    parser = BodyfileParser('bodyfile', **input)
    return parser.parse()
    

if __name__ == '__main__':
    import json
    input = {}
    results = parse(**input)
    print(json.dumps(results, indent=2))