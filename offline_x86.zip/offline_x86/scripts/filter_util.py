"""Filtering for forensic search results"""
import re

from pathlib_improved import Path
from parser_utils import ForensicLogger
from typing import Optional, Dict, List, Any

logger = ForensicLogger.get_logger()


def in_list(value: str, match_values: list):
    return value in match_values


def apply_filters(results: list, filters: Optional[Dict[str, List[Any]]], filters_map: dict):
    """Apply filters on results list"""
    if not filters:
        return results

    filtered_results = []
    for result in results:
        is_match = True
        for filter_name, filter_value in filters.items():

            #  Make sure the filter name is valid filter name +
            if not filter_name in filters_map:
                logger.warn(f"Skipping filter name: '{filter_name}' is invalid for that script.")
                continue

            # clear empty string values from lists
            if isinstance(filter_value, list):
                filter_value = list(filter(lambda x: x or x==0 , filter_value))
            
            # if the filter value is falsy skip the filter
            if not filter_value:
                continue

            filter_type, field_name = filters_map[filter_name]
            if filter_type == "in_list":
                found = False 
                for key in field_name.split(","):
                    if in_list(result.get(key), filter_value):
                        found = True
                        break

                if not found:
                    is_match = False
                    break
            
            elif filter_type == "wildcards_path":
                found = False
                for key in field_name.split(","):
                    path = Path(result.get(key) or "")
                    if any(path.match(pattern) for pattern in filter_value):
                        found = True
                        break
                    
                if not found:
                    is_match = False
                    break         
            
            elif filter_type == "regex_filename":
                file_name = Path(result.get(field_name) or "").name
                if not any(re.search(pattern, file_name, re.IGNORECASE) for pattern in filter_value):
                    is_match = False
                    break
            
            elif filter_type == "regex":
                value = result.get(field_name, "")
                if not any(re.search(pattern, value, re.IGNORECASE) for pattern in filter_value):
                    is_match = False
                    break
            elif filter_type == "case_sensitive_regex":
                value = result.get(field_name, "")
                if not any(re.search(pattern, value) for pattern in filter_value):
                    is_match = False
                    break            
            elif filter_type == "user_search_list":
                found = False
                for item in filter_value:
                    item_type = item["type"] 
                    if item_type == "user_name":
                        key = field_name["user_name"]

                    elif item_type == "user_id":
                        key = field_name["user_id"]

                    # That should not happen
                    else:
                        raise Exception(f"Invalid filter type: \"{item['type']}\"")

                    value = item["value"]
                    result_value = result.get(key)
                    if result_value is not None :
                        if hasattr(result_value, '__iter__'):
                            if value in result_value:
                                found = True
                                break
                        elif value == result_value:
                            found = True
                            break

                if not found:
                    is_match = False
                    break

            else:
                raise Exception(f"Unsupported filter {filter_name}")
            
            if not is_match:
                    break
        
        if is_match:
            filtered_results.append(result)

    return filtered_results

