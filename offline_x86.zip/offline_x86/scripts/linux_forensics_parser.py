import os
import sys
import time
from multiprocessing import Process
from threading import Thread
from pathlib import Path
import subprocess
#from abc import ABC , abstractmethod
from logging import getLogger
import parser_utils
from datetime import datetime
import zipfile
import pwd
import parser_utils
from filter_util import apply_filters
from forensic_parser import ForensicParser
import json
import posix_ipc


#steps : 
# 	1. run uac with specific profile and output directory
#	2. create costume.profile with all requested artifacr from the input   (translate from server req artifact to uac artifact type)
#	3. open the raw tar.gz artifact from output folder  [implement for each artifact a dedecated parser and ability to apply filters]
#		3.1. parse the raw data to the schema
#		3.2 filter the parsed data , by the requested filters 
#	4. send the parsed and filtered data  to server 

# lets devide to generic work ( translate artifact to profile , run the uac, send the parsed data ) and specific artifact method ( parsing and filtering)
#each artifact will be calss inherits from basiccommon class


class LinuxForensicsParser(ForensicParser):

	def __init__(self, input_file_path=None, script_name=None, **kwargs):
		super().__init__(script_name=script_name, **kwargs)
		self.run_from_offline_collector = False
		self.uac_extracted_flag = "/tmp/cortex_uac_extracted.flag"
		self.mutex_name = "/cortex-uac-extractor-mutex"
		if os.environ.get('IS_OFFLINE_COLLECTOR', '0') == '1':
			self.run_from_offline_collector = True
		self.artifacts_dir = "19700101000000000"f"_{os.getpid()}"
		#self.artifacts_dir = os.getcwd()
		if not self.run_from_offline_collector:
			self.deploy_dir = "/opt/traps"
			try:
				self.deploy_dir = os.environ["deploy_path"]
				self.logger.debug(f"found deploy path: {self.deploy_dir}")
			except KeyError:
				self.logger.error(f"not found deploy_path as env variable , use default value {self.deploy_dir}")
			self.uac_dir = Path(self.deploy_dir) / "download" / "uac" 
		else: # its offline collector 
			self.deploy_dir = os.path.dirname(os.path.dirname(os.getcwd()))
			self.uac_dir = Path(self.deploy_dir) / "uac"
			self.logger.debug("its offline collector. deploy path = {self.deploy_dir} , uac_dir = {self.uac_dir}")


	def is_uac_extracted_flag_set(self):
		"""Quick check if UAC is already extracted (no mutex needed)"""
		return os.path.exists(self.uac_extracted_flag)
	
	def set_uac_extracted_flag(self):
		"""Mark UAC as extracted"""
		self.logger.debug("uac flag is setting now")
		try:
			with open(self.uac_extracted_flag, 'w') as f:
				f.write(f"extracted_at:{time.time()}\n")
				f.write(f"pid:{os.getpid()}\n")
				f.write(f"uac_dir:{self.uac_dir}\n")
		except Exception as e:
			self.logger.warning(f"Could not set UAC extracted flag: {e}")

	def _check_and_extract_with_mutex(self, uac_zip_dir):
		"""Protected check and extraction with mutex"""
		mutex = None
		
		try:
			mutex = posix_ipc.Semaphore(self.mutex_name, flags=posix_ipc.O_CREAT, initial_value=1)
			
			try:
				mutex.acquire(timeout=30)
			except posix_ipc.BusyError:
				self.logger.error("UAC extraction mutex timeout")
				return False
			
			try:
				# Check again after acquiring mutex (another process might have extracted)
				if self.is_uac_extracted_flag_set() and os.path.exists(self.uac_dir):
					self.logger.debug("UAC already extracted and flag set")
					return True
				
				# Check if directory exists without flag
				if os.path.exists(self.uac_dir):
					self.logger.info("UAC already extracted but flag not set - lets set it")
					# Directory exists, set flag for future fast checks
					self.set_uac_extracted_flag()
					return True
				
				# Need to extract
				self.logger.info("Extracting UAC...")
				if self.extract_uac(uac_zip_dir) :
					# Set flag after successful extraction
					self.set_uac_extracted_flag()
					return True
					
				return False
				
			finally:
				mutex.release()
				
		except Exception as e:
			self.logger.error(f"UAC deployment check failed: {e}")
			return False
		finally:
			if mutex:
				mutex.close()

	def extract_uac(self, uac_zip_dir):
		try:	
			uac_src_zip = Path(uac_zip_dir).absolute() / "uac.zip"

			if not os.path.exists(self.uac_dir):
				os.makedirs(self.uac_dir)
			with zipfile.ZipFile(str(uac_src_zip), 'r') as zip_ref:
				zip_ref.extractall(str(self.uac_dir))

			total_files = LinuxForensicsParser.count_files_recursive(self.uac_dir)
			self.logger.info(f"Successfully extracted UAC.zip to {self.uac_dir} with {total_files} files")
			return True
		except Exception as e:
			self.logger.error(f"Error extracting UAC.zip: {e}")
			return False

	def is_uac_deployed(self):
		"""
		Extract UAC.zip from content folder to download folder
		"""
		try:
			if self.is_uac_extracted_flag_set():
				if os.path.exists(self.uac_dir):
					return True
				else:
					# Flag exists but directory missing - clean up flag
					try:
						os.remove(self.uac_extracted_flag)
					except Exception as e:
						self.logger.error(f"cant remove extracted flag: {e}")
						return False
					
			if not self.run_from_offline_collector:
				#just for online , not offline collector 
				symlink = Path(self.deploy_dir) / "download" / "content"	
				if not symlink.exists() or not symlink.is_symlink():
					self.logger.warning(f"Symlink {symlink} does not exist or is not a valid symlink")
					return False
				# Validate input file path
				content_path = symlink.resolve()
				if content_path.exists():
					self.logger.debug(f"resolved symlink to  {content_path}")
					res = self._check_and_extract_with_mutex(str(content_path))
					return res
				else : 
					return False
			else : #its offline collector 
				res = self._check_and_extract_with_mutex(str(self.deploy_dir))
				return res
		except Exception as e:
			self.logger.error(f"Error in extract_uac: {e}")
			return False
	
	def verify_uac_permissions(self,uac_file_path):
		if os.path.exists(uac_file_path):
			os.chmod(uac_file_path, 0o744)  # Ensure executable permissions for owner only
		else:
			self.logger.error(f"UAC executable not found at {uac_file_path}")
			raise FileNotFoundError(f"UAC executable not found at {uac_file_path}")


	def collect_artifacts(self, artifact_file_path):
		# ./uac -p ir_triage /tmp
		orig_dir = os.getcwd()
		os.chdir(str(self.uac_dir))
		uac_filename = "uac"
		uac = str(Path(uac_filename).absolute())
		self.verify_uac_permissions(uac)
		now = datetime.now()
		artifact_timestamp =  now.strftime("%Y%m%d%H%M%S") + f"_{os.getpid()}"
		#Path(self.deploy_dir) 
		self.artifacts_dir = Path(self.deploy_dir) / "tmp/out_artifacts" / artifact_timestamp
		if not os.path.exists(str(self.artifacts_dir)):
			os.makedirs(str(self.artifacts_dir))

		command_parts = [
			uac,
			"-a",
			str(artifact_file_path),
			str(self.artifacts_dir)
			]
		try:
			# Set up a clean environment without LD_LIBRARY_PATH to avoid library conflicts
			env = os.environ.copy()
			if 'LD_LIBRARY_PATH' in env:
				del env['LD_LIBRARY_PATH']
			
			# Run the command with the modified environment
			result = subprocess.run(command_parts, shell=False, capture_output=True, text=True, check=True, env=env)
			self.logger.info(result.stdout)
			self.logger.info(result.stderr)
		except subprocess.CalledProcessError as e:
			self.logger.error(f"uac command failed with error code {e.returncode}: {e.stderr}")
			raise e
		finally:
			os.chdir(orig_dir)
		
	def extract_collected_artifacts(self):
		"""
		Extract collected artifacts from the output directory

		Args:
			artifacts_dir (str): Path to directory containing collected artifacts

		Returns:
			list: List of paths to extracted artifact directories
		"""
		orig_dir = os.getcwd()
		os.chdir(str(self.artifacts_dir))
		# Find all tar.gz files
		path = Path(self.artifacts_dir)
		tar_file = None
		for file_path in path.glob('**/*.tar.gz'):
			file_base_name = os.path.basename(file_path)
			if str(file_base_name).startswith("uac") and str(file_base_name).endswith(".tar.gz"):
				tar_file = str(file_path)
				break	
		# Extract each tar.gz file to its own directory
		if tar_file is not None:
			# Create extraction directory based on tar filename
			try:
				extract_dir = os.path.join(self.artifacts_dir, os.path.splitext(os.path.splitext(os.path.basename(tar_file))[0])[0])
				os.makedirs(extract_dir, exist_ok=True)
			except Exception as e:
				self.logger.error(f"Failed to extract {tar_file} , {extract_dir}: {e}")
			# Extract the tar.gz file
			try:
				command_parts = [
					'tar',
					'-xzf',
					tar_file,
					'-C',
					extract_dir
				]
				subprocess.run(command_parts, check=True,  shell=False)
				self.logger.info(f"Successfully extracted {tar_file} to {extract_dir}")
				return extract_dir
			except subprocess.CalledProcessError as e:
				self.logger.error(f"Failed to extract {tar_file}: {e}")
				return None
			finally:
				os.chdir(orig_dir)
		else:
			self.logger.warning("No tar.gz file found for extraction")
			return None

	def clean_sources(self):
		"""
		Clean up collected artifacts and temporary directories after parsing is complete
		"""
		try:
			# Remove artifacts directory if it exists
			if os.path.exists(str(self.artifacts_dir)):
				command_parts = [
						'rm',
						'-rf',
						str(self.artifacts_dir)
					]
				subprocess.run(command_parts, check=True, shell=False)
				self.logger.info(f"Cleaned up artifacts directory: {self.artifacts_dir}")
		except Exception as e:
			self.logger.error(f"Error cleaning up artifacts: {e}")

	def create_profile(self):
		raise NotImplementedError

	def parse_artifacts_to_schema(self,extracted_dir):
		raise NotImplementedError

	def get_filter_map(self):
		return {}

	#@abstractmethod
	def apply_filter(self, parsed_data):   
		filtered_data = apply_filters(parsed_data, self.kwargs.get('filters', {}), self.get_filter_map())
		return filtered_data


	@staticmethod
	def get_user_by_path(file_path,specific_artifact_dir):
		etc_dir = specific_artifact_dir / 'etc'
		home_dir = specific_artifact_dir / 'home'
		if file_path.is_relative_to(etc_dir):
			user = 'global'
		elif file_path.is_relative_to(home_dir):
			relative_to_home = file_path.relative_to(home_dir)
			user = relative_to_home.parts[0] if relative_to_home.parts else 'root'
		else:
			user ='root'
		return user
	
	@staticmethod
	def convert_to_int(val):
		"""
		Safe integer conversion with fallback
		"""
		try:
			return int(val)
		except (ValueError, TypeError):
			return -1

	@staticmethod
	def get_userId(user):
		try:
			user_info = pwd.getpwnam(user)
			user_id = user_info.pw_uid
		except KeyError:
			user_id = -1  
		return user_id
	

	@staticmethod
	def get_file_metadate(file_path, entity):
		file_stats  = os.stat(file_path)
		relative_path = '/'+os.path.relpath(file_path)
		entity.update({
			'file_path': str(relative_path),
			'file_created' : file_stats.st_birthtime if hasattr(file_stats, 'st_birthtime') else None,
			'file_modified': file_stats.st_mtime,
			'file_changed': file_stats.st_ctime
		})

	@staticmethod
	def count_files_recursive(directory):
		"""Count files recursively using os.walk()"""
		file_count = 0
		for _, _, files in os.walk(directory):
			file_count += len(files)
		return file_count


	def parse(self):
		try:
			filtered_data = None
			#extract to uac.zip from content folder to download folder
			if not self.is_uac_deployed():
				self.logger.error("cant deploy uac tool")
				if os.path.exists(self.uac_dir):
					os.remove(self.uac_dir)
				return filtered_data
			profile = self.create_profile()  # pylint: disable=E1111
			self.logger.debug(f"profile created : {profile}")
			self.collect_artifacts(profile)
			self.logger.debug("artifact collected successfully")
			self.logger.debug(f"Current time before filtering: {datetime.now()}")
			extracted_dir = self.extract_collected_artifacts()
			parsed_data = self.parse_artifacts_to_schema(extracted_dir) # pylint: disable=E1111
			self.logger.debug(f"before filtering data: {json.dumps(parsed_data, indent = 4)}")
			filtered_data = self.apply_filter(parsed_data)
			self.logger.info(f"num of enties: {len(filtered_data)}")

			super().process()
			self._result_data()['entries'] = filtered_data
			self.logger.debug(f"Current time after filtering: {datetime.now()}")

		except Exception as e:
			self.logger.exception(f"Error during parsing process: {e}")
		finally:
			#self.clean_sources(extracted_dir)
			self.clean_sources()
		self.logger.debug(f"filtered data: {json.dumps(self.get_results(), indent = 4)}")
		return self.get_results()
		#return filtered_data


