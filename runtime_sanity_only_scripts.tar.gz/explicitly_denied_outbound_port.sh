#!/bin/bash
curl 8.8.4.4:8888
