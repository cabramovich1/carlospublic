#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Denied explicitly IP\n….Triggering....\n"

curl 1.1.1.1

echo -e "\nEvent information:\nCategory:Network / Explicitly Denied IP\nATT%CK technique:NO TECHNIQUE\nMessage:Outbound connection by /usr/bin/curl to IP 1.1.1.1:80 is explicitly denied by a runtime rule"
