#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Changes to SSH and admin account configuration files\n\n...Triggering....\n"

echo Aasdasd >> /etc/passwd

echo -e "\nEvent information:\nCategory:Filesystem / Administrative Account\nATT%CK technique:Create Account, Account Manipulation\nMessage:/usr/bin/bash wrote to administrative accounts configuration file /etc/passwd, could be related to a backdoor attack"
