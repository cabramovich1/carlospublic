#!/bin/bash
#xmrig -B --coin=monero --url=stratum+tcp://xmr.pool.minergate.com:45700 --user=3FFUDWRvZ9wQ1cLEWQTstgeoDkMiXoXEeH --pass=[*****] --max-cpu-usage=100 &
#sleep 1
#pkill -9 xmrig
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nTOGGLE:Crypto miners\n\n....Triggering....\n"

cp -v /bin/sleep /tmp/xmrig && /tmp/xmrig 5

echo -e "\nEvent information:\nCategory:Processes / Crypto Miner Process \nATT%CK technique:Resource Hijacking\nMessage:/tmp/xmrig launched and is identified as a crypto miner. Full command: /tmp/xmrig 5"


