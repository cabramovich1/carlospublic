#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Detection of encrypted/packed binaries\n\n….Triggering....\n"

curl -LO https://github.com/cabramovich1/carlospublic/raw/main/server.dynamic.elf

echo -e "\nEvent information:\nCategory:Filesystem / Encrypted Binary\nATT%CK technique:Obfuscated Files\nMessage:/usr/bin/curl wrote a suspicious packed/encrypted binary to /tools/server.dynamic.elf. Packing/encryption can conceal malicious executables. MD5: d8519a2ef2cea1549ff2e69f83b686df"
