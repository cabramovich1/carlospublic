#!/bin/bash

#ANTI-MALWARE SCRIPTS
./kubectl_spawned.sh
./kubelet_api_access.sh
./kubelet_readonly_access.sh
./cloud_metadata_probing.sh

#PROCESSES SCRIPTS
./modified_process.sh
./crypto_miner.sh
./reverse_shell.sh
./lateral_move.sh
./SUID_binaries.sh
./explicitly_denied_processes.sh
./unexpected_processes.sh

#NETWORK-OUTGOING > IP CONNECTIVITY SCRIPTS
./port_scan.sh
./raw_socket.sh
./explicitly_denied_listening_port.sh
./explicitly_denied_IP.sh
./unexpected_listening_port.sh

#NETWORK-OUGOING > DOMAIN SCRIPTS
./explicitly_denied_domain.sh
./dns_query.sh

#FILESYSTEM SCRIPTS
./change_to_binaries_fs.sh
./reg_access.sh
./administrative_account.sh
./ssh_access.sh
./secret_access.sh
./explicitly_denied_file.sh
./encrypted_binary.sh
./malware_download.sh
./wildfire_runtime.sh

#CUSTOM RULE SCRIPTS
./custom_rule_processes_dd.sh
./custom_rule_network_outgoing_1_0_0_1.sh
./custom_rule_filesystem_tools_general_files.sh
