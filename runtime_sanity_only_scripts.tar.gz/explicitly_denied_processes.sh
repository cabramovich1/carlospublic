#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Denied Processes Field \n….Triggering....\n"

date

echo -e "\nEvent information:\nCategory:Processes / Explicitly Denied Process \nATT%CK technique:Native Binary Execution\nMessage:/usr/bin/date launched and is explicitly denied by a runtime rule. Full command: date
