#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nTOGGLE:Processes started with SUID\n….Triggering....\n"

mount

echo -e "\nEvent information:\nCategory:Processes / Suid Binaries \nATT%CK technique:Abuse Elevation Control Mechanisms\nMessage:/usr/bin/mount launched and is detected as a process started with SUID. Full command: mount"
