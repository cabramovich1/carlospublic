#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:NO TOGGLE, All other paths\n\n….Triggering....\n"

echo -ne "-----BEGIN PRIVATE KEY-----\nXXX\n-----END PRIVATE KEY-----" >  /tools/key12.pem


echo -e "\nEvent information:\nCategory:Filesystem / Secret File Access\nATT%CK technique:NO TECHNIQUE\nMessage:/usr/bin/bash created a key file at /tools/key12.pem"
