#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:RUNTIME CUSTOM RULE WILL HAVE PRIORITY OVER RUNTIME CONTAINER POLICY\n\n….Triggering....\n"

dd --help

echo -e '\nEvent information:\nCategory:Processes / Custom Rule\nATT%CK technique:NO TECHNIQUE\nMessage:mailto: carlos@mail.com; auth: [*****] DD (name: "dd", parent: "bash", path: "/usr/bin/dd", user: "root", interactive: "true", cmd: "dd", service: "")'
