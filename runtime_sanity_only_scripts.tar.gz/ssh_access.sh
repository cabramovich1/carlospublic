#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Changes to SSH and admin account configuration files\n\n...Triggering....\n"

mkdir -p /root/.ssh && sleep 2 && echo Aasdasd >> /root/.ssh/foo1.pem && sleep 3 && echo x > /dev/tcp/8.8.8.8/53

echo -e "\nEvent information:\nCategory:Filesystem / SSH Access\nATT%CK technique:NO TECHNIQUE\nMessage:/usr/bin/bash wrote to SSH configuration file /root/.ssh/foo1.pem, could be related to a backdoor attack"
