#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:Port Scanning\n....Triggering....\n"

nmap --help

echo -e "\nEvent information:\nCategory:Processes / Port Scan Process \nATT%CK technique:Network Service Scanning\nMessage:/usr/bin/nmap launched and is identified as a process used for port scanning. Full command: nmap --help
