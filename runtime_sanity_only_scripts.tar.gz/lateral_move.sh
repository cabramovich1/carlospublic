#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nTOGGLE:Processes used for lateral movement\n….Triggering....\n"

nc --help
pkill -9 netcat
pkill -9 ncat

echo -e "\nEvent information:\nCategory:Processes / Lateral Movement Process \nATT%CK technique:NONE\nMessage:/usr/bin/nc.openbsd launched and is identified as a process used for lateral movement. Full command: nc --help"
