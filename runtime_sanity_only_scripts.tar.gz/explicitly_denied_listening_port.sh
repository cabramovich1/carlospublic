#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Denied explicitly listing ports field\n….Triggering....\n"

nc -k -l -p 10000 &
sleep 20
pkill -9 nc

echo -e "\nEvent1 information:\nCategory:Network / Explicitly Denied Listening Port \nATT%CK technique:NO TECHNIQUE\nMessage:Container process /usr/bin/nc.openbsd is listening on port 10000 explicitly denied by a runtime rule"
