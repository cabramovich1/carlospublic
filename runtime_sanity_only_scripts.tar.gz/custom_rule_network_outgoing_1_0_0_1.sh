#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:RUNTIME CUSTOM RULE WILL HAVE PRIORITY OVER RUNTIME CONTAINER POLICY\n\n….Triggering....\n"

curl 1.0.0.1

echo -e '\nEvent information:\nCategory:Network / Custom Rule\nATT%CK technique:NO TECHNIQUE\nMessage:token=[*****] , token:[*****] "pass"=[*****], key=[*****], secret:[*****], auth:[*****] code=[*****], cert=[*****], proxy:[*****], thumbprint:[*****]'
