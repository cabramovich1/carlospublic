#!/bin/bash
echo -e "Conditions:\nLearning:Does not matter\nTOGGLE:NO TOGGLE, Denied Domain field \n....Triggering....\n"

curl www.yahoo.com

echo -e "\nEvent information:TWICE for IPv4 type A and if VPC support IPv6 TWICE  type AAAA\nCategory:Network / Explicitly Denied DNS\nATT%CK technique:NO TECHNIQUE\nMessage:DNS resolution of name www.yahoo.com, type A explicitly denied by a runtime rule"
