#!/bin/bash
echo -e "Conditions:\nLearning:OFF or CONTAINER MODEL ACTIVE\nTOGGLE:NO TOGGLE, All other domains\n\n....Triggering....\n"

curl www.facebook.com

echo -e "\nEvent information:at least 1 for  IPv4 type A and if  support IPv6 at least one  type AAAA\nCategory:Network / DNS Query\nATT%CK technique:NO TECHNIQUE\nMessage:DNS resolution of suspicious name www.facebook.com, type A"
