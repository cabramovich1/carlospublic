#!/bin/bash
echo -e "Conditions:\nLearning:OFF of CONTAINER MODEL ACTIVE\nTOGGLE:NO TOGGLE, All Other effects \n....Triggering....\n"

ps

echo -e "\nEvent information:\nCategory:Processes / Unexpected Process \nATT%CK technique:Native Binary Execution\nMessage:/usr/bin/ps launched but is not found in the runtime model. Full command: /usr/bin/ps"
